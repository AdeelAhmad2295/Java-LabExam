package VehicleRentalSystem;

import java.io.*;
import java.util.*;

// Customer class to store customer details
class Customer implements Serializable {
    private int customerId;
    private String name;

    public Customer(int customerId, String name) {
        this.customerId = customerId;
        this.name = name;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Name: " + name;
    }
}

// Vehicle class to store vehicle details
class Vehicle implements Serializable {
    private int vehicleId;
    private String type;
    private boolean isAvailable;

    public Vehicle(int vehicleId, String type) {
        this.vehicleId = vehicleId;
        this.type = type;
        this.isAvailable = true;  // By default, the vehicle is available
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public String getType() {
        return type;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean available) {
        isAvailable = available;
    }

    @Override
    public String toString() {
        return "Vehicle ID: " + vehicleId + ", Type: " + type + ", Available: " + (isAvailable ? "Yes" : "No");
    }
}

// Rental class to manage rental transactions
class Rental implements Serializable {
    private int rentalId;
    private Vehicle vehicle;
    private Customer customer;
    private int rentalDuration; // in days

    public Rental(int rentalId, Vehicle vehicle, Customer customer, int rentalDuration) {
        this.rentalId = rentalId;
        this.vehicle = vehicle;
        this.customer = customer;
        this.rentalDuration = rentalDuration;
    }

    @Override
    public String toString() {
        return "Rental ID: " + rentalId + ", Vehicle: " + vehicle + ", Customer: " + customer + ", Duration: " + rentalDuration + " days";
    }
}

// VehicleRentalSystem class to manage vehicles and rentals
public class VehicleRentalSystem {
    private static List<Customer> customers = new ArrayList<>();
    private static List<Vehicle> vehicles = new ArrayList<>();
    private static List<Rental> rentals = new ArrayList<>();
    private static int rentalCounter = 1;

    private static final String LOG_FILE = "rental_log.txt";

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Vehicle Rental System ---");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Vehicle");
            System.out.println("3. View Available Vehicles");
            System.out.println("4. Rent Vehicle");
            System.out.println("5. Return Vehicle");
            System.out.println("6. View Rentals");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        addCustomer(sc);
                        break;
                    case 2:
                        addVehicle(sc);
                        break;
                    case 3:
                        viewAvailableVehicles();
                        break;
                    case 4:
                        rentVehicle(sc);
                        break;
                    case 5:
                        returnVehicle(sc);
                        break;
                    case 6:
                        viewRentals();
                        break;
                    case 7:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    // Add a new customer
    private static void addCustomer(Scanner sc) {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        System.out.print("Enter customer name: ");
        sc.nextLine(); // consume newline
        String name = sc.nextLine();

        customers.add(new Customer(customerId, name));
        System.out.println("Customer added successfully.");
    }

    // Add a new vehicle
    private static void addVehicle(Scanner sc) {
        System.out.print("Enter vehicle ID: ");
        int vehicleId = sc.nextInt();
        System.out.print("Enter vehicle type: ");
        sc.nextLine(); // consume newline
        String type = sc.nextLine();

        vehicles.add(new Vehicle(vehicleId, type));
        System.out.println("Vehicle added successfully.");
    }

    // View all available vehicles
    private static void viewAvailableVehicles() {
        boolean foundAvailable = false;
        System.out.println("--- Available Vehicles ---");
        for (Vehicle vehicle : vehicles) {
            if (vehicle.isAvailable()) {
                System.out.println(vehicle);
                foundAvailable = true;
            }
        }
        if (!foundAvailable) {
            System.out.println("No vehicles are currently available.");
        }
    }

    // Rent a vehicle
    private static void rentVehicle(Scanner sc) throws IOException {
        System.out.print("Enter vehicle ID to rent: ");
        int vehicleId = sc.nextInt();
        Vehicle vehicle = findVehicleById(vehicleId);
        if (vehicle == null || !vehicle.isAvailable()) {
            System.out.println("Vehicle is not available for rent.");
            return;
        }

        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        Customer customer = findCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }

        System.out.print("Enter rental duration (in days): ");
        int rentalDuration = sc.nextInt();

        // Create rental and update vehicle status
        rentals.add(new Rental(rentalCounter++, vehicle, customer, rentalDuration));
        vehicle.setAvailable(false); // Update vehicle availability
        logRental(vehicle, customer, rentalDuration); // Log the rental
        System.out.println("Vehicle rented successfully.");
    }

    // Return a vehicle
    private static void returnVehicle(Scanner sc) {
        System.out.print("Enter vehicle ID to return: ");
        int vehicleId = sc.nextInt();
        Vehicle vehicle = findVehicleById(vehicleId);
        if (vehicle == null || vehicle.isAvailable()) {
            System.out.println("Vehicle is not rented or not found.");
            return;
        }

        vehicle.setAvailable(true); // Update vehicle availability
        System.out.println("Vehicle returned successfully.");
    }

    // View all rentals
    private static void viewRentals() {
        if (rentals.isEmpty()) {
            System.out.println("No rentals available.");
        } else {
            System.out.println("--- Rental History ---");
            for (Rental rental : rentals) {
                System.out.println(rental);
            }
        }
    }

    // Find a vehicle by its ID
    private static Vehicle findVehicleById(int vehicleId) {
        for (Vehicle vehicle : vehicles) {
            if (vehicle.getVehicleId() == vehicleId) {
                return vehicle;
            }
        }
        return null;
    }

    // Find a customer by their ID
    private static Customer findCustomerById(int customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId) {
                return customer;
            }
        }
        return null;
    }

    // Log the rental details to a file
    private static void logRental(Vehicle vehicle, Customer customer, int rentalDuration) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
            writer.write("Rental - Vehicle: " + vehicle + ", Customer: " + customer + ", Duration: " + rentalDuration + " days");
            writer.newLine();
        }
    }
}
