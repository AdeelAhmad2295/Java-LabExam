package Shop;

import java.io.*;
import java.util.*;

// Product class to manage product details
class Product implements Serializable {
    private int productId;
    private String productName;
    private double price;
    private int stockQuantity;

    public Product(int productId, String productName, double price, int stockQuantity) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stockQuantity = stockQuantity;
    }

    public int getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    @Override
    public String toString() {
        return "Product ID: " + productId + ", Name: " + productName + ", Price: " + price + ", Stock: " + stockQuantity;
    }
}

// Customer class to manage customer details
class Customer implements Serializable {
    private int customerId;
    private String customerName;
    private String contactNumber;

    public Customer(int customerId, String customerName, String contactNumber) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.contactNumber = contactNumber;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    @Override
    public String toString() {
        return "Customer ID: " + customerId + ", Name: " + customerName + ", Contact: " + contactNumber;
    }
}

// Transaction class to handle sales and billing
class Transaction implements Serializable {
    private int transactionId;
    private Customer customer;
    private Product product;
    private int quantity;
    private double totalAmount;

    public Transaction(int transactionId, Customer customer, Product product, int quantity) {
        this.transactionId = transactionId;
        this.customer = customer;
        this.product = product;
        this.quantity = quantity;
        this.totalAmount = product.getPrice() * quantity;
        product.setStockQuantity(product.getStockQuantity() - quantity);
    }

    @Override
    public String toString() {
        return "Transaction ID: " + transactionId + "\n" +
                "Customer: " + customer.getCustomerName() + "\n" +
                "Product: " + product.getProductName() + "\n" +
                "Quantity: " + quantity + "\n" +
                "Total Amount: $" + totalAmount;
    }
}

// Main Shop Management System class
public class ShopManagementSystem {
    private static List<Product> products = new ArrayList<>();
    private static List<Customer> customers = new ArrayList<>();
    private static List<Transaction> transactions = new ArrayList<>();
    private static int transactionIdCounter = 1;

    public static void main(String[] args) {
        loadFiles(); // Load data from files if available
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Shop Management System ---");
            System.out.println("1. Add Product");
            System.out.println("2. Update Product");
            System.out.println("3. Remove Product");
            System.out.println("4. Show Product Stock");
            System.out.println("5. Register Customer");
            System.out.println("6. Process Sale");
            System.out.println("7. Show Sales Report");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        addProduct(sc);
                        break;
                    case 2:
                        updateProduct(sc);
                        break;
                    case 3:
                        removeProduct(sc);
                        break;
                    case 4:
                        showProductStock();
                        break;
                    case 5:
                        registerCustomer(sc);
                        break;
                    case 6:
                        processSale(sc);
                        break;
                    case 7:
                        showSalesReport();
                        break;
                    case 8:
                        saveFiles(); // Save data to files before exiting
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    // Add new product
    private static void addProduct(Scanner sc) {
        System.out.print("Enter product ID: ");
        int productId = sc.nextInt();
        System.out.print("Enter product name: ");
        String productName = sc.next();
        System.out.print("Enter product price: ");
        double price = sc.nextDouble();
        System.out.print("Enter stock quantity: ");
        int stockQuantity = sc.nextInt();

        products.add(new Product(productId, productName, price, stockQuantity));
        System.out.println("Product added successfully.");
    }

    // Update product details
    private static void updateProduct(Scanner sc) {
        System.out.print("Enter product ID to update: ");
        int productId = sc.nextInt();

        Product product = findProductById(productId);
        if (product == null) {
            System.out.println("Product not found!");
            return;
        }

        System.out.print("Enter new price: ");
        double price = sc.nextDouble();
        System.out.print("Enter new stock quantity: ");
        int stockQuantity = sc.nextInt();

        product.setStockQuantity(stockQuantity);
        System.out.println("Product updated successfully.");
    }

    // Remove product
    private static void removeProduct(Scanner sc) {
        System.out.print("Enter product ID to remove: ");
        int productId = sc.nextInt();

        Product product = findProductById(productId);
        if (product == null) {
            System.out.println("Product not found!");
            return;
        }

        products.remove(product);
        System.out.println("Product removed successfully.");
    }

    // Show product stock
    private static void showProductStock() {
        if (products.isEmpty()) {
            System.out.println("No products available.");
            return;
        }

        System.out.println("--- Product Stock ---");
        for (Product product : products) {
            System.out.println(product);
        }
    }

    // Register new customer
    private static void registerCustomer(Scanner sc) {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        System.out.print("Enter customer name: ");
        String customerName = sc.next();
        System.out.print("Enter contact number: ");
        String contactNumber = sc.next();

        customers.add(new Customer(customerId, customerName, contactNumber));
        System.out.println("Customer registered successfully.");
    }

    // Process sale and generate bill
    private static void processSale(Scanner sc) {
        System.out.print("Enter customer ID: ");
        int customerId = sc.nextInt();
        Customer customer = findCustomerById(customerId);
        if (customer == null) {
            System.out.println("Customer not found!");
            return;
        }

        System.out.print("Enter product ID: ");
        int productId = sc.nextInt();
        Product product = findProductById(productId);
        if (product == null) {
            System.out.println("Product not found!");
            return;
        }

        System.out.print("Enter quantity: ");
        int quantity = sc.nextInt();
        if (quantity > product.getStockQuantity()) {
            System.out.println("Insufficient stock!");
            return;
        }

        Transaction transaction = new Transaction(transactionIdCounter++, customer, product, quantity);
        transactions.add(transaction);
        System.out.println("Sale processed successfully.");
        System.out.println("--- Bill ---");
        System.out.println(transaction);
    }

    // Show sales report
    private static void showSalesReport() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions available.");
            return;
        }

        System.out.println("--- Sales Report ---");
        for (Transaction transaction : transactions) {
            System.out.println(transaction);
            System.out.println();
        }
    }

    // Find product by ID
    private static Product findProductById(int productId) {
        for (Product product : products) {
            if (product.getProductId() == productId) {
                return product;
            }
        }
        return null;
    }

    // Find customer by ID
    private static Customer findCustomerById(int customerId) {
        for (Customer customer : customers) {
            if (customer.getCustomerId() == customerId) {
                return customer;
            }
        }
        return null;
    }

    // Load data from files
    private static void loadFiles() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("products.dat"))) {
            products = (List<Product>) ois.readObject();
        } catch (Exception e) {
            System.out.println("No product data found.");
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("customers.dat"))) {
            customers = (List<Customer>) ois.readObject();
        } catch (Exception e) {
            System.out.println("No customer data found.");
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("transactions.dat"))) {
            transactions = (List<Transaction>) ois.readObject();
        } catch (Exception e) {
            System.out.println("No transaction data found.");
        }
    }

    // Save data to files
    private static void saveFiles() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("products.dat"))) {
            oos.writeObject(products);
        } catch (IOException e) {
            System.out.println("Failed to save product data.");
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("customers.dat"))) {
            oos.writeObject(customers);
        } catch (IOException e) {
            System.out.println("Failed to save customer data.");
        }

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("transactions.dat"))) {
            oos.writeObject(transactions);
        } catch (IOException e) {
            System.out.println("Failed to save transaction data.");
        }
    }
}
